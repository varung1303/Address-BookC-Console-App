﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{
    
    

    class ContactUserInterface : IContactUserInterface
    {
        IContactService contactService = new ContactService();
        enum Commands
        {
            Create=1,
            Read=2,
            Update=3,
            Delete=4,
            Search=5,
            Exit=6
        }
        
        
        public void MainMenu()
        {

            
            int command = 0;
            while (command != 6)
            {
                
                Console.Clear();
                Console.WriteLine("Please enter your option number: ");
                Console.WriteLine("1. Create\tCreates a contact in the address book");
                Console.WriteLine("2. Read         Display all contacts from address book");
                Console.WriteLine("3. Update\tUpdate a contact from address book");
                Console.WriteLine("4. Delete\tDelete a contact in the address book");
                Console.WriteLine("5. Search\tSearches for a contact in the address book by its first name");
                Console.WriteLine("6. Exit The Application");
                command = Convert.ToInt32(Console.ReadLine());



                switch (command)
                {
                    case (int)Commands.Create:
                        AddContact();
                        break;
                    case (int)Commands.Read:
                        DisplayAllContacts();
                        break;
                    case (int)Commands.Update:
                        EditContact();
                        break;
                    case (int)Commands.Delete:
                        RemoveContact();
                        break;
                    case (int)Commands.Search:
                        SearchContact();
                        break;
                    case (int)Commands.Exit:
                        Environment.Exit(0);
                        break;
                    default:

                        if (command != 6)
                        {
                            DisplayHelp();
                        }
                        break;
                }
            }
        }

        public void DisplayHelp()
        {
            Console.Clear();
            Console.WriteLine("Please enter your option number: ");
            Console.WriteLine("1. Create\tCreates a contact in the address book");
            Console.WriteLine("2. Read         Display all contacts from address book");
            Console.WriteLine("3. Update\tUpdate a contact from address book");
            Console.WriteLine("4. Delete\tDelete a contact in the address book");
            Console.WriteLine("5. Search\tSearches for a contact in the address book by its first name");
            Console.WriteLine("6. Exit The Application");
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }
        public void DisplayAllContacts()
        {
            List<Contact> listOfContact = contactService.GetListOfContact();
            Console.Clear();
            if (listOfContact.Count == 0)
            {
                Console.WriteLine("Your address book is empty. Press any key to continue.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Here are the current people in your address book:\n");
            foreach (var person in listOfContact)
            {
                DisplayContact(person);
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();

        }

        public void DisplayContact(Contact contactForPrint)
        {
            Console.WriteLine("Name: " + contactForPrint.Name);
            Console.WriteLine("Mail: " + contactForPrint.Mail);
            Console.WriteLine("Mobile: " + contactForPrint.Mobile);
            Console.WriteLine("Landline: " + contactForPrint.Landline);
            Console.WriteLine("Website: " + contactForPrint.Website);
            Console.WriteLine("Address: " + contactForPrint.Address);

            Console.WriteLine("---------------------------------------");
        }
        public void AddContact()
        {
            Contact contact = new Contact();

            Console.Write("Enter Name: ");
            contact.Name = Console.ReadLine();

            Console.Write("Enter Mail-id: ");
            contact.Mail = Console.ReadLine();

            Console.Write("Enter Mobile Number: ");
            contact.Mobile = Console.ReadLine();

            Console.Write("Enter Landline Number: ");
            contact.Landline = Console.ReadLine();

            Console.Write("Enter Website: ");
            contact.Website = Console.ReadLine();

            Console.Write("Enter Address: ");
            contact.Address = Console.ReadLine();
            contactService.AddContactToList(contact);
        }

       

        public void SearchContact()
        {
            Console.WriteLine("Enter the first name of the person you would like to find.");
            string firstName = Console.ReadLine();

            List<Contact> contactListByName = contactService.getContactByFirstName(firstName);
            Console.Clear();
            if (contactListByName.Count == 0)
            {
                Console.WriteLine("That person could not be found. Press any key to continue");
                Console.ReadKey();
                return;

            }
            Console.WriteLine("Here are the current people in your address book matching that search:\n");

            foreach (var person in contactListByName)
            {
                DisplayContact(person);
            }
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();

        }

        public void EditContact()
        {
            
            Console.WriteLine("Enter the first name of the person you would like to Edit.");
            string firstName = Console.ReadLine();
            List<Contact> contactListForEdit = contactService.getContactByFirstName(firstName);

            if (contactListForEdit.Count == 0)
            {

                Console.WriteLine("That person could not be found. Press any key to continue");
                Console.ReadKey();
                return;
            }
            else if (contactListForEdit.Count == 1)
            {
                
                EditPersonFromList(contactListForEdit.Single());
                return;
            }
            else
            {
                for (int i = 0; i < contactListForEdit.Count; i++)
                {
                    Console.WriteLine(i);
                    DisplayContact(contactListForEdit.ElementAt(i));
                }
                Console.WriteLine("Enter the number of the person to Edit:");
                int editPersonNumber = Convert.ToInt32(Console.ReadLine());
                if (editPersonNumber > contactListForEdit.Count - 1 || editPersonNumber < 0)
                {
                    Console.WriteLine("That number is invalid. Press any key to continue.");
                    Console.ReadKey();
                    return;
                }
                EditPersonFromList(contactListForEdit.ElementAt(editPersonNumber));

            }


        }


        public void EditPersonFromList(Contact contactForEdit)
        {
            
            Console.WriteLine("Are you sure you want to edit this person in your address book? (Y/N)");

            DisplayContact(contactForEdit);

            if (Console.ReadKey().Key == ConsoleKey.Y)
            {


                Console.WriteLine("Enter Name:" );
                contactForEdit.Name = Console.ReadLine();


                Console.WriteLine("Enter Mail:" );
                contactForEdit.Mail = Console.ReadLine();


                Console.WriteLine("Enter Mobile:" );
                contactForEdit.Mobile = Console.ReadLine();


                Console.WriteLine("Enter Landline:" );
                contactForEdit.Landline = Console.ReadLine();


                Console.WriteLine("Enter Website:");
                contactForEdit.Website = Console.ReadLine();


                Console.WriteLine("Enter Address:");
                contactForEdit.Address = Console.ReadLine();

                Console.WriteLine("Press any key to continue.");
                Console.ReadKey();


            }
        }
        public void RemoveContact()
        {
            Console.WriteLine("Enter the first name of the person you would like to Delete.");
            string firstName = Console.ReadLine();
            List<Contact> contactListForDelete = contactService.getContactByFirstName(firstName);

            if (contactListForDelete.Count == 0)
            {
                Console.WriteLine("That person could not be found. Press any key to continue");
                Console.ReadKey();
                return;
            }
            else if (contactListForDelete.Count == 1)
            {
                Console.WriteLine("Are you sure you want to remove this person from your address book? (Y/N)");
                DisplayContact(contactListForDelete.Single());
                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    contactService.RemovePersonFromList(contactListForDelete.Single());
                    return;
                }
            }

            Console.WriteLine("Enter the number of the person you wish to delete:");
            for (int i = 0; i < contactListForDelete.Count; i++)
            {
                Console.WriteLine(i);
                DisplayContact(contactListForDelete.ElementAt(i));
            }
            int removePersonNumber = Convert.ToInt32(Console.ReadLine());
            if (removePersonNumber > contactListForDelete.Count - 1 || removePersonNumber < 0)
            {
                Console.WriteLine("That number is invalid. Press any key to continue.");
                Console.ReadKey();
                return;
            }
            Console.WriteLine("Are you sure you want to remove this person from your address book? (Y/N)");
            DisplayContact(contactListForDelete.ElementAt(removePersonNumber));
            if (Console.ReadKey().Key == ConsoleKey.Y)
            {
                contactService.RemovePersonFromList(contactListForDelete.ElementAt(removePersonNumber));
            }
        }


    }

}
