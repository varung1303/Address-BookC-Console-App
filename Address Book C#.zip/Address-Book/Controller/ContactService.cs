﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{

    
    public class ContactService : IContactService
    {
        ContactList contactList;
        public ContactService()
        {
            contactList = new ContactList();
        }

        public List<Contact> GetListOfContact()
        {
            return contactList.GetList;
        }
        

        public void AddContactToList(Contact contact)
        {
            contactList.AddToList = contact;
        }

        public void RemovePersonFromList(Contact contactForDelete)
        {
            contactList.RemoveFromList=contactForDelete;
            Console.ReadKey();
        }

        public List<Contact> getContactByFirstName(string name)
        {
            return contactList.GetList.Where(x => x.Name.ToLower() == name.ToLower()).ToList();
        }
    }

}
