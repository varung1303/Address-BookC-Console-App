﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{


    public class ContactList
    {
        private List<Contact> ListOfContacts;

        public ContactList()
        {
            ListOfContacts = new List<Contact>();
        }

        public Contact AddToList
        {
            
            set
            {
                ListOfContacts.Add(value);
            }
        }

        public List<Contact> GetList
        {
            get
            {
                return ListOfContacts;
            }
        }

        public Contact RemoveFromList
        {
            set
            {
                ListOfContacts.Remove(value);
            }
        }

       
        
    }


}


