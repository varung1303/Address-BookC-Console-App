﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{

    
        public class Contact
        {
            private string name;
            private string mail;
            private string mobile;
            private string landline;
            private string website;
            private string address;

            

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public string Mail
        {
            get
            {
                return mail;
            }
            set
            {
                mail = value;
            }
        }
        public string Mobile
        {
            get
            {
                return mobile;
            }
            set
            {
                mobile = value;
            }
        }
        public string Landline
        {
            get
            {
                return landline;
            }
            set
            {
                landline = value;
            }
        }
        public string Website
        {
            get
            {
                return website;
            }
            set
            {
                website = value;
            }
        }
        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }

    }
}


