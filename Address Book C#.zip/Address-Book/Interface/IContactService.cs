﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{

    public interface IContactService
    {
        void AddContactToList(Contact c);
        void RemovePersonFromList(Contact contactForDelete);
        List<Contact> getContactByFirstName(string name);
        List<Contact> GetListOfContact();



    }
}
