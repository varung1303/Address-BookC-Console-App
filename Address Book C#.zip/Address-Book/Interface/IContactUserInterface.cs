﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Address_Book
{

    public interface IContactUserInterface
    {
        void MainMenu();
        void DisplayHelp();
        void DisplayAllContacts();
        void DisplayContact(Contact c);
        void AddContact();
        void RemoveContact();
        void SearchContact();
        void EditContact();
        void EditPersonFromList(Contact contactForEdit);

    }

}
